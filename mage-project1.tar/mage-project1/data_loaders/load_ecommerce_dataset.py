import os
import subprocess

os.environ['KAGGLE_USERNAME'] = 'YOUR_KAGGLE_USERNAME'
os.environ['KAGGLE_KEY'] = 'YOUR_KAGGLE_KEY'

# Unduh menggunakan kaggle CLI langsung
subprocess.run([
    'kaggle', 'datasets', 'download',
    '-d', 'retailrocket/ecommerce-dataset',
    '--unzip', '-p', './data'
])
