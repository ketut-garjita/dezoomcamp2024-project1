from mage_ai.settings.repo import get_repo_path
from mage_ai.io.config import ConfigFileLoader
from mage_ai.io.google_cloud_storage import GoogleCloudStorage
import os
import pandas as pd
from pandas import DataFrame
from os import path
import pyarrow as pa
import pyarrow.parquet as pq 
import datetime as dt
from datetime import date


if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

config_path = path.join(get_repo_path(), 'io_config.yaml')
config_profile = 'default'

@data_exporter 
def export_data3(item_properties_part1, *args, **kwargs):
    bucket_name = kwargs.get('bucket_name')
    item_properties_part1_path = f'{bucket_name}/ecommerce/item_properties_part1'

    table = pa.Table.from_pandas(item_properties_part1)
    gcs = pa.fs.GcsFileSystem()
    pq.write_to_dataset(
        table,
        existing_data_behavior="delete_matching",      
        root_path=item_properties_part1_path,
        filesystem=gcs     
    )
    return item_properties_part1
