import io
import pandas as pd
import requests
import opendatasets as od
from multiprocessing import Process
import sys
import glob 

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Template for loading data from API
    """
    
    item_properties_part_dtypes = {
        'timestamp'     : pd.Int64Dtype(),
        'itemid'        : pd.Int64Dtype(),
        'property'      : object,
        'value'         : object
    }

    # Merge item_properties_part dataset
    # part1 = "ecommerce-dataset/item_properties_part1.csv"
    # part2 = "ecommerce-dataset/item_properties_part2.csv"

    # item_properties_part = pd.concat(
    #     map(pd.read_csv, [part1, part2]), 
    #     ignore_index=True)

    folder_path = 'ecommerce-dataset'
    file_list = glob.glob(folder_path + "/item_properties_part*.csv")

    # Initialize an empty list to store the chunked dataframes
    dfs = []

    for file in file_list:
        # Read the CSV file in chunks
        # Adjust the chunksize as per your memory capacity
        reader = pd.read_csv(file, chunksize=5000, 
            dtype=item_properties_part_dtypes)

        # Iterate through each chunk and append it to the list
        for chunk in reader:
            dfs.append(chunk)
        
        # Concatenate all the chunks into a single dataframe
        item_properties = pd.concat(dfs, ignore_index=True)
        
        # Return output    
        return item_properties
        print(item_properties)
    