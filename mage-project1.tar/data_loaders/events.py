import io
import pandas as pd
import requests
import  opendatasets as od
from multiprocessing import Process
import sys

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Template for loading data from API
    """
    
    events_dtypes = {
        'timestamp'     : pd.Int64Dtype(),
        'visitorid'     : pd.Int64Dtype(),
        'event'         : object,
        'itemid'        : pd.Int64Dtype(),
        'transactionid' : pd.Int64Dtype()
    }

    # Read data
    events = pd.read_csv('ecommerce-dataset/events.csv', encoding='unicode_escape', dtype=events_dtypes)
    #events[["transactionid"]] = events[["transactionid"]].fillna(0)
    
    #pdevents = pd.read_csv('ecommerce-dataset/events.csv')
    #pdevents = pdevents.fillna(0)
    
    # Return output    
    return events
    