import io
import pandas as pd
import requests
import  opendatasets as od
from multiprocessing import Process
import sys

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data_from_api(*args, **kwargs):
    """
    Template for loading data from API
    """
    
    item_properties_part1_dtypes = {
        'timestamp'     : pd.Int64Dtype(),
        'itemid'        : pd.Int64Dtype(),
        'property'      : object,
        'value'         : object
    }
 
    # Read data
    item_properties_part1 = pd.read_csv('ecommerce-dataset/item_properties_part1.csv', encoding='unicode_escape', dtype=item_properties_part1_dtypes)
 
    # Return output    
    return item_properties_part1
